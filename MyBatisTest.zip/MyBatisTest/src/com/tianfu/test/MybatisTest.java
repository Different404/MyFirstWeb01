package com.tianfu.test;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.junit.Test;

import com.tianfu.po.Staff;
import com.tianfu.utils.MybatisUtils;

public class MybatisTest {
	
	public static void main(String[] args) throws IOException{
		
		
		MybatisTest mybatisTest = new MybatisTest();
		//mybatisTest.findStaffByIdTest(2);
		//mybatisTest.findStaffByNameAndJobsTest("","");
		//mybatisTest.findStaffByNameAndEmailTest("","");
		//mybatisTest.updateStaffByIdTest(4, "jack", "boy", "student", "1364960145");
		//mybatisTest.findStaffByIdsTest(); 
		//mybatisTest.insertStaffTest("Nancy", "gril", "teacher", "14596301236@qq.com", "13602362365");
		mybatisTest.deleteStaffTest(4);
	}
	

	public void findStaffByIdTest(int id)throws IOException{
		SqlSession sqlSession = MybatisUtils.getSession();
		Staff staff = sqlSession.selectOne("com.tianfu.Mapper.StaffMapper.findStaffById",id);
		System.out.println(staff.toString());
		sqlSession.close();
	}
	
	@Test
	public void findStaffByNameAndJobsTest(String username, String jobs){
		SqlSession sqlSession = MybatisUtils.getSession();
		Staff staff = new Staff();
		staff.setUsername(username);
		staff.setJobs(jobs);
		List<Staff> staffs = sqlSession.selectList("com.tianfu.Mapper.StaffMapper.findStaffByNameAndJobs",staff);
		for (Staff staff2 : staffs) {
			System.out.println(staff2);
		}
		sqlSession.close();
	}
	
	public void findStaffByNameAndEmailTest(String username,String jobs) {
		SqlSession sqlSession = MybatisUtils.getSession();
		Staff staff = new Staff();
		staff.setUsername(username);
		staff.setJobs(jobs);
		List<Staff> staffs = sqlSession.selectList("com.tianfu.Mapper.StaffMapper.findStaffByNameAndEmail",staff);
		for (Staff staff2 : staffs) {
			System.out.println(staff2);
		}
		sqlSession.close();
	}
	public void updateStaffByIdTest(int id,String username,String sex,String jobs,String phone) {
		SqlSession sqlSession = MybatisUtils.getSession();
		Staff staff = new Staff();
		staff.setId(id);
		staff.setUsername(username);
		staff.setSex(sex); 
		staff.setJobs(jobs); 
		staff.setPhone(phone);
		 
		int rows = sqlSession.update("com.tianfu.Mapper.StaffMapper.updateStaffById",staff);
		if (rows>0) {
			System.out.println("��ɹ����޸�"+rows+"������");
		}else {
			System.out.println("�޸�����ʧ��");
		}
		sqlSession.commit();
		sqlSession.close();
	}
	
	public void findStaffByIdsTest() {
		SqlSession sqlSession = MybatisUtils.getSession();
		
		List<Integer> ids=new ArrayList<Integer>();
		ids.add(1);
		ids.add(2);
		List<Staff> staffs=sqlSession.selectList("com.tianfu.Mapper.StaffMapper.findStaffByIds",ids);
		for (Staff staff : staffs) {
			System.out.println(staff);
		}
	
		sqlSession.close();
	}
	
	public void insertStaffTest(String username,String sex,String jobs,String email,String phone) {
		SqlSession sqlSession = MybatisUtils.getSession();
		Staff staff=new Staff();
		staff.setUsername(username);
		staff.setSex(sex);
		staff.setJobs(jobs);
		staff.setEmail(email);
		staff.setPhone(phone);
		int rows = sqlSession.insert("com.tianfu.Mapper.StaffMapper.insertStaff", staff);
		if (rows>0) {
			System.out.println("��ɹ�����"+rows+"������");
		}else {
			System.out.println("����ʧ��");
		}
		sqlSession.commit();
		System.out.println(staff.getId());
		sqlSession.close();
	}
	
	public void deleteStaffTest(int id) {
		SqlSession sqlSession = MybatisUtils.getSession();
		int rows = sqlSession.delete("com.tianfu.Mapper.StaffMapper.deleteStaff", id);
		if (rows>0) {
			System.out.println("��ɹ�ɾ��"+rows+"������");
		}else {
			System.out.println("ɾ��ʧ��");
		}
		sqlSession.commit();
		sqlSession.close();
	}
}
