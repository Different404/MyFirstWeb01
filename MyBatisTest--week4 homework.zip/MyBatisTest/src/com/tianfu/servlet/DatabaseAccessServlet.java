package com.tianfu.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.catalina.ant.FindLeaksTask;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;

/**
 * Servlet implementation class DatabaseAccessServlet
 */
@WebServlet("/DatabaseAccessServlet")
public class DatabaseAccessServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
	static final String DB_URL = "jdbc:mysql://localhost:3306/mybatis";
    
	static final String  USER = "root";
	static final String PASS = "ab123654";
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DatabaseAccessServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		Connection connection = null;
		Statement stmtStatement = null;
		
		response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        String title = "Servlet Mysql ���� - ����̳�";
        String docType = "<!DOCTYPE html>\n";
        out.println(docType +
        "<html>\n" +
        "<head><title>" + title + "</title></head>\n" +
        "<body bgcolor=\"#f0f0f0\">\n" +
        "<h1 align=\"center\">" + title + "</h1>\n");
		try {
			Class.forName("com.mysql.jdbc.Driver");
			connection = (Connection) DriverManager.getConnection(DB_URL, USER, PASS);
			stmtStatement = (Statement) connection.createStatement();
			
			String sql;
			sql = "select id,username,sex,jobs,email,phone from staff";
			ResultSet rs = stmtStatement.executeQuery(sql);
			
			while (rs.next()) {
				int id = rs.getInt("id");
				String username = rs.getString("username");
				String sex = rs.getString("sex");
				String jobs = rs.getString("jobs");
				String email = rs.getString("email");
				String phone = rs.getString("phone");
				
				out.println("id:"+id);
				out.println(",�û���:"+username);
				out.println(",�Ա�:"+sex);
				out.println(",ְλ:"+jobs);
				out.println(",�ʼ�:"+email);
				out.println(",�绰:"+phone);
				out.println("<br/>");
			}
			out.println("</body></html>");
			
			rs.close();
			stmtStatement.close();
			connection.close();
		} catch (SQLException se) {
			// TODO: handle exception
			se.printStackTrace();
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			try {
				if (stmtStatement != null) 
					stmtStatement.close();
			} catch (SQLException se2) {
				// TODO: handle exception
			}
			try {
				if (connection != null) 
				connection.close();
			} catch (SQLException se) {
				se.printStackTrace();
			}
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
