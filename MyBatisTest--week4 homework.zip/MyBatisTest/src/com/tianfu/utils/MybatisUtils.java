package com.tianfu.utils;

import java.io.Reader;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

public class MybatisUtils {
	private static SqlSessionFactory sqlSessionFactory = null;
	
	private static SqlSessionFactory getSqlSessionFactory() {
		
		if(sqlSessionFactory == null)
			try {
				//���������ļ�
				Reader reader = Resources.getResourceAsReader("Mybatis-config.xml");
				//�����Ự����
				sqlSessionFactory = new SqlSessionFactoryBuilder().build(reader);
			} catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
			}
		
		return sqlSessionFactory;
	}
	
	public static SqlSession getSession() {
		if(null == sqlSessionFactory) {
			getSqlSessionFactory();
		}
		return sqlSessionFactory.openSession();
	}

}
